class Levels:
    def __init__(self):
        self.levels = [
            # Level 1 - Medium
            [
                "ggwwwwwwwwwwww",
                "ggggwwwwwwwggw",
                "wwwgwgwwgggwgw",
                "gwggwgwwwwwggw",
                "gwgwwwwwggwwww",
                "gwgggggwgwwwww",
                "gwwwwwggwggggw",
                "gwggwwgggwwwww",
                "gwgwwwggggwwgw",
                "ggwwgggwwggwgw",
                "wwwwwwwwgggggf"
            ],
            # Level 2 - Hard
            [
                "ggggggwwwwwwww",
                "gwwwwgwwwwwwgw",
                "ggwgwggggwwwgg",
                "wwwwwwwggwgggg",
                "ggggggwwgggwgw",
                "gwwwwgwwwwwwgg",
                "ggggwgwwwggggw",
                "gwwgwwwwggwwww",
                "gwwwwwwggwgggw",
                "wwggwwwgwwgwgw",
                "wwwwwwwggggwgf"
            ],
            # Level 3 - Very Hard
            [
                "ggggwwwwwwwwwg",
                "wgwwwwggggwwgg",
                "ggggwgggwgwwgg",
                "gwwgggwgwwgwgg",
                "ggwwwgwggggwgg",
                "ggggwgwwwwgggw",
                "wwwgwwwggwgwww",
                "gwwwgggwgwgggw",
                "gwwwwwwwgwwggw",
                "wgggggwwggggwg",
                "fgwwwgggggwwgw"
            ]
        ]

    def get_level(self, level_number):
        return self.levels[level_number] 