from enum import Enum

class GameState:
    MENU = 0
    PLAYING = 1
    LEVEL_SELECT = 2

class GameStateManager:
    def __init__(self):
        self.state = GameState.MENU
        self.current_level = 1
        self.score = 0
        self.time = 0 