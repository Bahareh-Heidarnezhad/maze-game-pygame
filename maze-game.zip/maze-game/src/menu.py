import pygame
import random
import math

class Menu:
    def __init__(self):
        self.font_large = pygame.font.SysFont('Cooper Black', 50)
        self.font_small = pygame.font.SysFont('Cooper Black', 36)
        self.selected_option = 0
        self.current_menu = "main"
        self.main_options = ["Start Game", "Levels", "Quit"]
        self.level_options = ["Level 1", "Level 2", "Level 3", "Back"]
        
        # Star animation variables
        self.stars = []
        for _ in range(8):  # Create 8 stars
            self.stars.append({
                'x': random.randint(50, 400),
                'y': random.randint(20, 160),
                'size': random.randint(10, 20),
                'angle': 0,
                'speed': random.uniform(2, 4)
            })
        
    def draw_star(self, screen, x, y, size, angle):
        # Draw a decorative star
        points = []
        for i in range(10):
            radius = size if i % 2 == 0 else size/2
            ang = math.radians(angle + i * 36)
            points.append((
                x + radius * math.cos(ang),
                y + radius * math.sin(ang)
            ))
        pygame.draw.polygon(screen, (255, 215, 0), points)  # Gold color
        
    def draw_title_decoration(self, screen, text_rect):
        # Draw decorative lines
        line_color = (255, 215, 0)  # Gold color
        pygame.draw.line(screen, line_color, 
                        (text_rect.left - 40, text_rect.centery),
                        (text_rect.left - 10, text_rect.centery), 4)
        pygame.draw.line(screen, line_color,
                        (text_rect.right + 10, text_rect.centery),
                        (text_rect.right + 40, text_rect.centery), 4)
        
        # Update and draw stars
        for star in self.stars:
            star['angle'] += star['speed']
            self.draw_star(screen, star['x'], star['y'], star['size'], star['angle'])
        
    def draw(self, screen):
        screen.fill((0, 0, 0))
        
        if self.current_menu == "main":
            # Draw main title with shadow effect
            title_shadow = self.font_large.render("MAZE GAME", True, (100, 100, 100))
            title = self.font_large.render("MAZE GAME", True, (255, 255, 255))
            
            # Get title position
            title_rect = title.get_rect(center=(224, 80))
            shadow_rect = title_shadow.get_rect(center=(227, 83))  # Offset for shadow
            
            # Draw shadow and title
            screen.blit(title_shadow, shadow_rect)
            screen.blit(title, title_rect)
            
            # Draw decorations around title
            self.draw_title_decoration(screen, title_rect)
            
            # Draw menu options
            for i, option in enumerate(self.main_options):
                color = (255, 255, 0) if i == self.selected_option else (255, 255, 255)
                text = self.font_small.render(option, True, color)
                screen.blit(text, (224 - text.get_width()//2, 180 + i * 40))
        
        elif self.current_menu == "level_select":
            # Draw level selection title
            title = pygame.font.SysFont('Cooper Black', 50).render("Select Level", True, (255, 255, 255))
            screen.blit(title, (224 - title.get_width()//2, 80))
            
            # Draw level options
            for i, option in enumerate(self.level_options):
                color = (255, 255, 0) if i == self.selected_option else (255, 255, 255)
                text = self.font_small.render(option, True, color)
                screen.blit(text, (224 - text.get_width()//2, 180 + i * 40))
            
    def handle_input(self, event):
        if event.type == pygame.KEYDOWN:
            if self.current_menu == "main":
                if event.key == pygame.K_UP:
                    self.selected_option = (self.selected_option - 1) % len(self.main_options)
                elif event.key == pygame.K_DOWN:
                    self.selected_option = (self.selected_option + 1) % len(self.main_options)
                elif event.key == pygame.K_RETURN:
                    selected = self.main_options[self.selected_option]
                    if selected == "Levels":
                        self.current_menu = "level_select"
                        self.selected_option = 0
                        return None
                    return selected
            
            elif self.current_menu == "level_select":
                if event.key == pygame.K_UP:
                    self.selected_option = (self.selected_option - 1) % len(self.level_options)
                elif event.key == pygame.K_DOWN:
                    self.selected_option = (self.selected_option + 1) % len(self.level_options)
                elif event.key == pygame.K_RETURN:
                    selected = self.level_options[self.selected_option]
                    if selected == "Back":
                        self.current_menu = "main"
                        self.selected_option = 0
                        return None
                    return selected
        return None 