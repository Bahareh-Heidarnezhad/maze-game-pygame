import pygame
import os

class Player:
    def __init__(self):
        # Start position should be on a grass tile
        self.tile_x = 0
        self.tile_y = 0
        self.pixel_x = self.tile_x * 32
        self.pixel_y = self.tile_y * 32
        self.moving = False
        self.direction = "right"
        self.animation_frame = 0
        self.animation_time = 0
        self.animation_speed = 0.1
        self.player_size = 48
        
        # Load animations
        self.animations = {
            "right": [],
            "left": [],
            "up": [],
            "down": []
        }
        
        self.load_animations()
        self.image = self.animations["right"][0]

    def load_animations(self):
        for direction in self.animations.keys():
            for i in range(4):
                try:
                    img_path = os.path.join("assets", "images", "player", f"player_{direction}_{i}.png")
                    if not os.path.exists(img_path):
                        print(f"Error: Image file not found: {img_path}")
                        continue
                        
                    img = pygame.image.load(img_path).convert_alpha()
                    
                    # Scale to larger size
                    img = pygame.transform.scale(img, (self.player_size, self.player_size))
                    
                    self.animations[direction].append(img)
                except pygame.error as e:
                    print(f"Error loading image: player_{direction}_{i}.png")
                    print(f"Error details: {e}")
                except Exception as e:
                    print(f"Unexpected error loading image: {e}")

        # Set default image if no animations loaded
        if not any(self.animations.values()):
            # Create a simple colored square as fallback
            fallback = pygame.Surface((32, 32))
            fallback.fill((255, 0, 0))  # Red square as fallback
            for direction in self.animations.keys():
                self.animations[direction] = [fallback] * 4
        
        self.image = self.animations["right"][0]

    def move(self, dx, dy):
        self.tile_x += dx
        self.tile_y += dy
        self.moving = True

    def update(self, dt):
        # Smooth movement
        target_x = self.tile_x * 32
        target_y = self.tile_y * 32
        
        self.pixel_x += (target_x - self.pixel_x) * 0.2
        self.pixel_y += (target_y - self.pixel_y) * 0.2
        
        # Animation
        if self.moving:
            self.animation_time += dt
            if self.animation_time >= self.animation_speed:
                self.animation_time = 0
                self.animation_frame = (self.animation_frame + 1) % 4
                self.image = self.animations[self.direction][self.animation_frame]
        
        # Check if movement is complete
        if abs(self.pixel_x - target_x) < 1 and abs(self.pixel_y - target_y) < 1:
            self.moving = False
            self.pixel_x = target_x
            self.pixel_y = target_y 

    def draw(self, screen):
        # Center the player in the tile with more precise positioning
        offset_x = (32 - self.player_size) // 2
        offset_y = (32 - self.player_size) // 2
        screen.blit(self.image, (self.pixel_x + offset_x, self.pixel_y + offset_y)) 