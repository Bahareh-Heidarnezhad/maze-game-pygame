import pygame
from src.board import Board
from src.menu import Menu
from src.game_state import GameState, GameStateManager
from src.sound_manager import SoundManager
from src.particles import ParticleSystem

class MazeGame:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((448, 448))
        pygame.display.set_caption("Maze Game")
        
        self.state_manager = GameStateManager()
        self.board = Board()
        self.menu = Menu()
        self.sound_manager = SoundManager()
        self.particle_system = ParticleSystem()
        
        self.clock = pygame.time.Clock()
        self.running = True
        
        # Start background music
        self.sound_manager.play_music()
        
    def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000.0  # Convert to seconds
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    
                if self.state_manager.state == GameState.MENU:
                    action = self.menu.handle_input(event)
                    if action == "Start Game":
                        self.state_manager.state = GameState.PLAYING
                    elif action == "Quit":
                        self.running = False
                        
                elif self.state_manager.state == GameState.PLAYING:
                    self.board.handle_event(event)
            
            # Update
            if self.state_manager.state == GameState.PLAYING:
                self.board.update()
                self.particle_system.update(dt)
                
                # Check win condition
                if self.board.win:
                    self.sound_manager.play_sound('win')
                    self.particle_system.emit(
                        self.board.player.pixel_x + 16,
                        self.board.player.pixel_y + 16,
                        (255, 255, 0)
                    )
            
            # Draw
            self.screen.fill((0, 0, 0))
            
            if self.state_manager.state == GameState.MENU:
                self.menu.draw(self.screen)
            elif self.state_manager.state == GameState.PLAYING:
                self.board.draw(self.screen)
                self.particle_system.draw(self.screen)
            
            pygame.display.flip()

if __name__ == "__main__":
    game = MazeGame()
    game.run()
    pygame.quit() 