import pygame
import os

def cut_spritesheet(sheet_path, frame_width, frame_height):
    pygame.init()
    
    print(f"Looking for sprite sheet at: {sheet_path}")
    print(f"Current working directory: {os.getcwd()}")
    
    try:
        # Load the sprite sheet
        if not os.path.exists(sheet_path):
            print(f"Error: Cannot find {sheet_path}")
            return
            
        sheet = pygame.image.load(sheet_path)
        sheet_width, sheet_height = sheet.get_size()
        print(f"Sprite sheet size: {sheet_width}x{sheet_height}")
        
        # Create output directory if it doesn't exist
        output_dir = os.path.join("assets", "images", "player")
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            print(f"Created directory: {output_dir}")
        
        # Define the rows and columns for each direction
        directions = {
            "down": {
                "row": 0,
                "frames": [(0, 0), (1, 0), (2, 0), (3, 0)]  # column positions for each frame
            },
            "left": {
                "row": 1,
                "frames": [(0, 1), (1, 1), (2, 1), (3, 1)]
            },
            "right": {
                "row": 2,
                "frames": [(0, 2), (1, 2), (2, 2), (3, 2)]
            },
            "up": {
                "row": 3,
                "frames": [(0, 3), (1, 3), (2, 3), (3, 3)]
            }
        }
        
        # Cut the sheet into frames
        for direction, info in directions.items():
            for frame_num, (col, row) in enumerate(info["frames"]):
                # Calculate exact pixel positions
                x = col * frame_width
                y = row * frame_height
                
                # Create a surface with transparency
                frame_surface = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
                
                # Copy the exact frame from the sheet
                frame_rect = pygame.Rect(x, y, frame_width, frame_height)
                frame_surface.blit(sheet, (0, 0), frame_rect)
                
                # Save the frame
                filename = f"player_{direction}_{frame_num}.png"
                output_path = os.path.join(output_dir, filename)
                pygame.image.save(frame_surface, output_path)
                print(f"Saved frame to: {output_path}")
                
                # Debug info
                print(f"Cutting frame at position: x={x}, y={y}, width={frame_width}, height={frame_height}")
        
        print("Sprite sheet cut successfully!")
        
    except Exception as e:
        print(f"Error processing sprite sheet: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Get the absolute path to sara.png
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.dirname(current_dir)
    sheet_path = os.path.join(project_dir, "assets", "images", "player", "sara.png")
    
    print(f"Script directory: {current_dir}")
    print(f"Project directory: {project_dir}")
    print(f"Looking for sara.png at: {sheet_path}")
    
    # You can adjust these values based on your sprite sheet
    cut_spritesheet(
        sheet_path=sheet_path,
        frame_width=32,    # Adjust if needed
        frame_height=32    # Adjust if needed
    ) 