import pygame
import os

# Create the player directory if it doesn't exist
if not os.path.exists("assets/images/player"):
    os.makedirs("assets/images/player")

# Initialize Pygame
pygame.init()

# Colors for different directions
colors = {
    "right": (255, 0, 0),    # Red
    "left": (0, 255, 0),     # Green
    "up": (0, 0, 255),       # Blue
    "down": (255, 255, 0)    # Yellow
}

# Create sprites for each direction
for direction, color in colors.items():
    for frame in range(4):
        # Create a surface
        surface = pygame.Surface((32, 32))
        surface.fill((255, 255, 255))  # White background
        
        # Draw the character (simple rectangle that moves slightly each frame)
        offset = frame * 2  # Movement offset for animation
        if direction == "right":
            pygame.draw.rect(surface, color, (8 + offset, 8, 16, 16))
        elif direction == "left":
            pygame.draw.rect(surface, color, (16 - offset, 8, 16, 16))
        elif direction == "up":
            pygame.draw.rect(surface, color, (8, 16 - offset, 16, 16))
        elif direction == "down":
            pygame.draw.rect(surface, color, (8, 8 + offset, 16, 16))
            
        # Save the image
        filename = f"player_{direction}_{frame}.png"
        path = os.path.join("assets", "images", "player", filename)
        pygame.image.save(surface, path)

print("Player sprites created successfully!") 