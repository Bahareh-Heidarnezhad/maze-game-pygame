import pygame
import random
import math

class Particle:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.size = random.randint(2, 5)
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(2, 5)
        self.dx = math.cos(angle) * speed
        self.dy = math.sin(angle) * speed
        self.lifetime = 1.0  # seconds
        self.age = 0

    def update(self, dt):
        self.x += self.dx * dt
        self.y += self.dy * dt
        self.age += dt
        self.dy += 9.8 * dt  # gravity
        
    def draw(self, screen):
        alpha = 255 * (1 - self.age / self.lifetime)
        if alpha > 0:
            surface = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
            pygame.draw.circle(surface, (*self.color, alpha), 
                             (self.size//2, self.size//2), self.size//2)
            screen.blit(surface, (int(self.x), int(self.y)))

class ParticleSystem:
    def __init__(self):
        self.particles = []
        
    def emit(self, x, y, color, count=20):
        for _ in range(count):
            self.particles.append(Particle(x, y, color))
            
    def update(self, dt):
        self.particles = [p for p in self.particles if p.age < p.lifetime]
        for particle in self.particles:
            particle.update(dt)
            
    def draw(self, screen):
        for particle in self.particles:
            particle.draw(screen) 