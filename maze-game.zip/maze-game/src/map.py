import pygame
from .levels import Levels
import os

class Map:
    def __init__(self, level_number):
        self.grass = pygame.image.load(os.path.join("assets", "images", "tiles", "grass.png")).convert()
        self.wall = pygame.image.load(os.path.join("assets", "images", "tiles", "wall.png")).convert_alpha()
        self.finish = pygame.image.load(os.path.join("assets", "images", "tiles", "finish.png")).convert_alpha()
        
        # Scale wall to be thinner
        self.wall = pygame.transform.scale(self.wall, (26, 26))
        # Remove wall transparency
        # self.wall.set_alpha(200)  # Removed this line
        
        levels = Levels()
        self.map_data = levels.get_level(level_number)

    def get_tile(self, x, y):
        # Make sure coordinates are within bounds
        if 0 <= x < len(self.map_data[0]) and 0 <= y < len(self.map_data):
            return self.map_data[y][x]
        return 'w'  # Return wall for out of bounds 