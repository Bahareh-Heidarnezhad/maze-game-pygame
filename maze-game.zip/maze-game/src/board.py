import pygame
from .map import Map
from .player import Player
import os
pygame.font.init()

class Board:
    def __init__(self, level=0):
        self.current_level = level
        self.map = Map(self.current_level)
        self.player = Player()
        self.win = False
        self.lose = False
        self.message = ""
        self.font = pygame.font.SysFont('Cooper Black', 50)
        self.small_font = pygame.font.SysFont('Cooper Black', 24)
        self.time = 0
        self.time_font = pygame.font.SysFont('Cooper Black', 16)
        
        # Set time limit based on level
        if level == 0:
            self.time_limit = 10    # Level 1: 10 seconds
        elif level == 1:
            self.time_limit = 15    # Level 2: 15 seconds
        else:
            self.time_limit = 20    # Level 3: 20 seconds
            
        self.game_started = False
        self.game_over_selection = 0
        self.fail_sound = pygame.mixer.Sound('assets/sounds/fail.wav')
        self.trophy_img = pygame.image.load(os.path.join("assets", "images", "trophy.png")).convert_alpha()
        self.gameover_img = pygame.image.load(os.path.join("assets", "images", "over.png")).convert_alpha()

    def handle_event(self, event):
        if self.win or self.lose:  # Handle both win and lose screens
            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_LEFT, pygame.K_RIGHT]:
                    self.game_over_selection = 1 - self.game_over_selection
                elif event.key == pygame.K_RETURN:
                    if self.game_over_selection == 0:
                        # Restart the game
                        self.__init__(self.current_level)
                        return "restart"
                    else:
                        # Return to menu
                        return "menu"
            return None

        if event.type == pygame.KEYDOWN and not self.win and not self.lose:
            if event.key in [pygame.K_w, pygame.K_UP]:
                next_tile = self.map.get_tile(self.player.tile_x, self.player.tile_y - 1)
                if next_tile != "w":
                    self.player.move(0, -1)
                    self.player.direction = "up"
            elif event.key in [pygame.K_s, pygame.K_DOWN]:
                next_tile = self.map.get_tile(self.player.tile_x, self.player.tile_y + 1)
                if next_tile != "w":
                    self.player.move(0, 1)
                    self.player.direction = "down"
            elif event.key in [pygame.K_a, pygame.K_LEFT]:
                next_tile = self.map.get_tile(self.player.tile_x - 1, self.player.tile_y)
                if next_tile != "w":
                    self.player.move(-1, 0)
                    self.player.direction = "left"
            elif event.key in [pygame.K_d, pygame.K_RIGHT]:
                next_tile = self.map.get_tile(self.player.tile_x + 1, self.player.tile_y)
                if next_tile != "w":
                    self.player.move(1, 0)
                    self.player.direction = "right"

    def update(self, dt):
        if self.win or self.lose:
            return  # Don't update anything if game is over

        if not self.game_started:
            if self.player.moving:
                self.game_started = True
            return

        self.player.update(dt)
        if self.game_started:
            self.time += dt
        
        # Check time limit
        if self.time >= self.time_limit:
            self.lose = True
            self.message = "Time's Up!"
            if not hasattr(self, 'fail_sound_played'):
                self.fail_sound.play()
                self.fail_sound_played = True
            return
        
        # Check if player is on finish tile
        current_tile = self.map.get_tile(self.player.tile_x, self.player.tile_y)
        if current_tile == "f":
            self.win = True
            if not hasattr(self, 'win_sound_played'):
                pygame.mixer.Sound('assets/sounds/win.wav').play()
                self.win_sound_played = True

    def draw(self, screen):
        if not self.win and not self.lose:
            # Draw map
            for y in range(len(self.map.map_data)):
                for x in range(len(self.map.map_data[y])):
                    tile = self.map.get_tile(x, y)
                    if tile == "f":
                        screen.blit(self.map.finish, (x * 32, y * 32))
                    elif tile == "g":
                        screen.blit(self.map.grass, (x * 32, y * 32))
                    elif tile == "w":
                        screen.blit(self.map.wall, (x * 32, y * 32))
            
            # Draw player centered in tile
            offset_x = (32 - self.player.player_size) // 2
            offset_y = (32 - self.player.player_size) // 2
            screen.blit(self.player.image, (self.player.pixel_x + offset_x, self.player.pixel_y + offset_y))
            
            # Draw time with Cooper Black font
            minutes = int((self.time_limit - self.time) // 60)
            seconds = int((self.time_limit - self.time) % 60)
            
            
            # Draw timer text
            time_text = self.time_font.render(f"{minutes:02d}:{seconds:02d}", True, (255, 215, 0))  # Gold color
            screen.blit(time_text, (200, 5))  # Centered in the background
        
        if self.win:
            screen.fill((0, 0, 0))
            
            # Draw trophy image
            trophy_rect = self.trophy_img.get_rect(center=(224, 140))
            screen.blit(self.trophy_img, trophy_rect)
            
            # Add Play Again option with Cooper Black font
            text = self.small_font.render("PLAY AGAIN", True, (255, 255, 255))
            screen.blit(text, (224 - text.get_width()//2, 220))
            
            # Yes/No options with Cooper Black font
            yes_color = (255, 255, 0) if self.game_over_selection == 0 else (255, 255, 255)
            no_color = (255, 255, 0) if self.game_over_selection == 1 else (255, 255, 255)
            yes_text = self.small_font.render("YES", True, yes_color)
            no_text = self.small_font.render("NO", True, no_color)
            
            total_width = yes_text.get_width() + no_text.get_width() + 30
            start_x = 224 - total_width // 2
            screen.blit(yes_text, (start_x, 260))
            screen.blit(no_text, (start_x + yes_text.get_width() + 30, 260))
            
            if not hasattr(self, 'win_sound_played'):
                pygame.mixer.Sound('assets/sounds/win.wav').play()
                self.win_sound_played = True
            return

        if self.lose:
            screen.fill((0, 0, 0))
            
            # Draw game over image (made even smaller)
            scaled_size = (self.gameover_img.get_width() // 3, self.gameover_img.get_height() // 3)  # Scale to 33% instead of 50%
            scaled_gameover = pygame.transform.scale(self.gameover_img, scaled_size)
            gameover_rect = scaled_gameover.get_rect(center=(224, 60))
            screen.blit(scaled_gameover, gameover_rect)
            
            # Draw sad face
            center_x, center_y = 224, 160
            pygame.draw.circle(screen, (255, 215, 0), (center_x, center_y), 35)
            pygame.draw.circle(screen, (0, 0, 0), (center_x - 15, center_y - 10), 8)
            pygame.draw.circle(screen, (0, 0, 0), (center_x + 15, center_y - 10), 8)
            pygame.draw.arc(screen, (0, 0, 0), (center_x - 20, center_y + 5, 40, 30), 0, 3.14, 3)
            
            # Draw "PLAY AGAIN" text with Cooper Black font
            text = self.small_font.render("PLAY AGAIN", True, (255, 255, 255))
            screen.blit(text, (224 - text.get_width()//2, 220))
            
            # Yes/No options with Cooper Black font
            yes_color = (255, 255, 0) if self.game_over_selection == 0 else (255, 255, 255)
            no_color = (255, 255, 0) if self.game_over_selection == 1 else (255, 255, 255)
            yes_text = self.small_font.render("YES", True, yes_color)
            no_text = self.small_font.render("NO", True, no_color)
            
            total_width = yes_text.get_width() + no_text.get_width() + 30
            start_x = 224 - total_width // 2
            screen.blit(yes_text, (start_x, 260))
            screen.blit(no_text, (start_x + yes_text.get_width() + 30, 260)) 