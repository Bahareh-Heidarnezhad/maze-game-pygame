import pygame
import os

class SoundManager:
    def __init__(self):
        # Load sounds
        self.win_sound = pygame.mixer.Sound(os.path.join('assets', 'sounds', 'win.wav'))
        self.move_sound = pygame.mixer.Sound(os.path.join('assets', 'sounds', 'move.wav'))
        
        # Load and start background music
        pygame.mixer.music.load(os.path.join('assets', 'music', 'background.mp3'))
        pygame.mixer.music.set_volume(0.5)
        self.play_music()  # Start playing music
        
    def play_sound(self, sound_name):
        if sound_name == 'win':
            self.win_sound.play()
        elif sound_name == 'move':
            self.move_sound.play()
        
    def play_music(self):
        pygame.mixer.music.play(-1)  # -1 means loop indefinitely
        
    def stop_music(self):
        pygame.mixer.music.stop() 